package part1.part1.driveapp

class userLoginInfo
{
    companion object{
        var name:String=""
        var phone:String=""
        var itemId:Int=0
        var qty:Int=0
    }
}